# Decisions Log
Agent: record any ambiguity you resolved here (date, decision, reason).
